package com.simplilearn.Bookzy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookzyApplicationTests {

	@Test
	void contextLoads() {
	}

}
